package com.fretron.registrymanager

import io.confluent.kafka.schemaregistry.avro.AvroCompatibilityChecker
import io.confluent.kafka.schemaregistry.avro.AvroUtils
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.*

class AvroSchemaCompatibilityTest {
    private val schemaString1 =
        ("{\"type\":\"record\",\"name\":\"Vehicle\",\"namespace\":\"com.fretron.Model\",\"fields\":[{\"name\":\"customerId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleModel\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleMake\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vtsDeviceId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleRegistrationNumber\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"uuid\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"associatedWith\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isDeleted\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"createTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"updateTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"groups\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"orgId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"sharedWith\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"driverId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"attachedDocs\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"source\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isTrackingEnabled\",\"type\":[\"null\",\"boolean\"],\"default\":null}]}")
    private val schema1 = AvroUtils.parseSchema(schemaString1).schemaObj
    private val schemaString2 =
        ("{\"type\":\"record\",\"name\":\"Vehicle\",\"namespace\":\"com.fretron.Model\",\"fields\":[{\"name\":\"customerId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleModel\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleMake\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vtsDeviceId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleRegistrationNumber\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"uuid\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"associatedWith\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isDeleted\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"createTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"updateTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"groups\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"orgId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"sharedWith\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"driverId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"attachedDocs\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"source\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isTrackingEnabled\",\"type\":[\"null\",\"boolean\"],\"default\":null},{\"name\":\"groupsExtended\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"OrganisationGroup\",\"fields\":[{\"name\":\"uuid\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"orgId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"groupName\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"groupType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"sharedWith\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null}]}}],\"default\":null}]}")
    private val schema2 = AvroUtils.parseSchema(schemaString2).schemaObj
    private val schemaString3 =
        ("{\"type\":\"record\",\"name\":\"Vehicle\",\"namespace\":\"com.fretron.Model\",\"fields\":[{\"name\":\"customerId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleModel\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleMake\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vtsDeviceId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"vehicleRegistrationNumber\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"uuid\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}]},{\"name\":\"associatedWith\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isDeleted\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"createTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"updateTime\",\"type\":[\"null\",\"long\"],\"default\":null,\"logicalType\":\"timestamp-millis\"},{\"name\":\"groups\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"orgId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"sharedWith\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"driverId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"attachedDocs\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null},{\"name\":\"source\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"isTrackingEnabled\",\"type\":[\"null\",\"boolean\"],\"default\":null},{\"name\":\"groupsExtended\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"OrganisationGroup\",\"fields\":[{\"name\":\"uuid\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"orgId\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"groupName\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"groupType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"sharedWith\",\"type\":[\"null\",{\"type\":\"array\",\"items\":{\"type\":\"string\",\"avro.java.string\":\"String\"}}],\"default\":null}]}}],\"default\":null},{\"name\":\"truckLength\",\"type\":[\"null\",\"long\"],\"default\":null},{\"name\":\"loadCapacity\",\"type\":[\"null\",\"long\"],\"default\":null},{\"name\":\"floorType\",\"type\":[\"null\",{\"type\":\"string\",\"avro.java.string\":\"String\"}],\"default\":null},{\"name\":\"kmDriven\",\"type\":[\"null\",\"double\"],\"default\":null},{\"name\":\"mileageLoaded\",\"type\":[\"null\",\"double\"],\"default\":null},{\"name\":\"mileageEmpty\",\"type\":[\"null\",\"double\"],\"default\":null}]}")
    private val schema3 = AvroUtils.parseSchema(schemaString3).schemaObj

    /*
     * Backward compatibility: A new schema is backward compatible if it can be used to read the data
     * written in the previous schema.
     */
    @Test
    fun testBasicBackwardsCompatibility() {
        val checker = AvroCompatibilityChecker.BACKWARD_CHECKER
        assertTrue(
            "adding a field with default is a backward compatible change",
            checker.isCompatible(schema2, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field with default is a backward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field with default is a backward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema2))
        )
    }

    /*
     * Backward transitive compatibility: A new schema is backward compatible if it can be used to read the data
     * written in all previous schemas.
     */
    @Test
    fun testBasicBackwardsTransitiveCompatibility() {
        val checker = AvroCompatibilityChecker.BACKWARD_TRANSITIVE_CHECKER
        // All compatible
        assertTrue(
            "iteratively adding fields with defaults is a compatible change",
            checker.isCompatible(schema2, Arrays.asList(schema1))
        )
        assertTrue(
            "iteratively adding fields with defaults is a compatible change",
            checker.isCompatible(schema3, Arrays.asList(schema1))
        )
        assertTrue(
            "iteratively adding fields with defaults is a compatible change",
            checker.isCompatible(schema3, Arrays.asList(schema2))
        )
    }

    /*
     * Forward compatibility: A new schema is forward compatible if the previous schema can read data written in this
     * schema.
     */
    @Test
    fun testBasicForwardsCompatibility() {
        val checker = AvroCompatibilityChecker.FORWARD_CHECKER
        assertTrue(
            "adding a field is a forward compatible change",
            checker.isCompatible(schema2, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field is a forward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field is a forward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema2))
        )
    }

    /*
     * Forward transitive compatibility: A new schema is forward compatible if all previous schemas can read data written
     * in this schema.
     */
    @Test
    fun testBasicForwardsTransitiveCompatibility() {
        val checker = AvroCompatibilityChecker.FORWARD_TRANSITIVE_CHECKER
        // All compatible
        assertTrue(
            "iteratively removing fields with defaults is a compatible change",
            checker.isCompatible(schema2, Arrays.asList(schema1))
        )
        assertTrue(
            "iteratively removing fields with defaults is a compatible change",
            checker.isCompatible(schema3, Arrays.asList(schema1))
        )
        assertTrue(
            "iteratively removing fields with defaults is a compatible change",
            checker.isCompatible(schema3, Arrays.asList(schema2))
        )
    }

    /*
     * Full compatibility: A new schema is fully compatible if it’s both backward and forward compatible.
     */
    @Test
    fun testBasicFullCompatibility() {
        val checker = AvroCompatibilityChecker.FULL_CHECKER
        assertTrue(
            "adding a field with default is a backward and a forward compatible change",
            checker.isCompatible(schema2, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field with default is a backward and a forward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding a field with default is a backward and a forward compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema2))
        )
    }

    /*
     * Full transitive compatibility: A new schema is fully compatible if it’s both transitively backward
     * and transitively forward compatible with the entire schema history.
     */
    @Test
    fun testBasicFullTransitiveCompatibility() {
        val checker = AvroCompatibilityChecker.FULL_TRANSITIVE_CHECKER
        assertTrue(
            "adding default to a field is a compatible change",
            checker.isCompatible(schema2, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding default to a field is a compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema1))
        )
        assertTrue(
            "adding default to a field is a compatible change",
            checker.isCompatible(schema3, Collections.singletonList(schema2))
        )
    }
}